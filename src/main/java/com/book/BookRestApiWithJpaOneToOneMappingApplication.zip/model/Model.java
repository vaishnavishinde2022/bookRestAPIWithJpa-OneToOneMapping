package com.book.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.book.entity.Book;

@Component
//bellow Model class act as a model in MVC and responsible for to interact with database.
public class Model 
{
	/*
	 * @Autowired To injecting bean at run time.
	 */
	@Autowired
	BookRepository repo;
   public Book addBook(Book Bookobj)
   {
	   Book result=repo.save(Bookobj);
	   
	   return result;
   }
}
