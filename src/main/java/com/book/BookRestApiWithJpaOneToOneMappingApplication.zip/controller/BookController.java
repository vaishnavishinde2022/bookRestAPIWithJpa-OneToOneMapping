package com.book.controller;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.book.model.Model;

import com.book.entity.Book;

@RestController
public class BookController 
{
	/*
	 * @Autowired To injecting bean at run time.
	 */
	@Autowired
	Model modelObj;
	
	/*
	 * @PostMapping to map the POST Http request
	 */
   @PostMapping("/add")
   
   /*
    * ResponseEntity represents an HTTP responses,status code,header,body.
    */
   public ResponseEntity<Book> addBook(@RequestBody Book bookObj)
   {
	   Book bookObj1;
	   bookObj1=modelObj.addBook(bookObj);
	   
	   return ResponseEntity.of(Optional.of(bookObj1));
   }
   
   
}
